import os
import rclpy
from rclpy.node import Node

class autoware_car_sim(Node):
    def __init__(self) :
        super().__init__('autoware_car_sim')
        self.get_logger().info("\033[1;32m %s \033[0m" % "autoware_car_sim is running ...")
        os.system("cd /home/robot/autoware_auto/PythonAPI/ && python3 autoware_car.py")
        
def main(args=None):
    rclpy.init(args=args)
    autoware_car_sim_node = autoware_car_sim()
    autoware_car_sim_node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()