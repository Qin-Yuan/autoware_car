import os
import rclpy
from rclpy.node import Node

class autoware_lgsvl_bridge(Node):
    def __init__(self) :
        super().__init__('autoware_lgsvl_bridge')
        # 终端输出绿色
        self.get_logger().info("\033[1;32m %s \033[0m" % "lgsvl_bridge is running ...")
        os.system("lgsvl_bridge")
def main(args=None):
    rclpy.init(args=args)
    autoware_lgsvl_bridge_node = autoware_lgsvl_bridge()
    autoware_lgsvl_bridge_node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()