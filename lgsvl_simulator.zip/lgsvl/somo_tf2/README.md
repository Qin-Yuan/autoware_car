# somo_tf2

## 介绍
提供SOMO机器人坐标变换以及位姿管理功能
---

## 前期准备
* Ubuntu 20.04
* ROS (foxy)


## 安装教程
执行下面终端命令来安装依赖项和编译：
```bash
#依赖项
sudo pip3 install transforms3d
sudo apt install ros-<distro>-tf-transformations

#编译
cd <WORKSPACE>
colcon build --symlink-install
```

---

## 运行
启动tf2，已经集成到somo_webots启动文件中

