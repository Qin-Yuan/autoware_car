#!/usr/bin/env python
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from tf2_ros import TransformBroadcaster,StaticTransformBroadcaster
from geometry_msgs.msg import Point32, TransformStamped, PoseStamped, Twist ,PointStamped
from sensor_msgs.msg import Imu,LaserScan,PointCloud2,CompressedImage
from nav_msgs.msg import Odometry
import numpy as np
import time

'''
    autoware 联合 LGSVL 仿真器的 TF2 变换包
'''
class TF2(Node):
    def __init__(self):
        super().__init__('_tf2')
        i = 0 
        self.declare_parameter("autoware_mode", "NONE")
        self.lgsvl_state = self.get_parameter("autoware_mode").get_parameter_value().string_value
        while self.lgsvl_state == "NONE" :
            self.lgsvl_state = self.get_parameter("autoware_mode").get_parameter_value().string_value   # robot or car
            self.get_logger().warn("Please set the autoware_mode param or the param is unuseful ... %d" % i)
            i = i + 1
            time.sleep(1)
            
        self._br = TransformBroadcaster(self)
        autoware_callback_group = MutuallyExclusiveCallbackGroup()
        
        '''
            autoware_mode  : robot or car
        '''
        #############
        #   robot 
        #############
        if self.lgsvl_state == "robot" :
            self._robot_static_mo = StaticTransformBroadcaster(self)      # map 到 robot_odom 静态连接
            self._robot_static_bs = StaticTransformBroadcaster(self)      # robot_base_footprint 到 robot_laser_link 静态连接
            
            # 里程计
            self._robot_odom = Odometry()                       # odom数据
            self._robot_odom_tf2 = TransformStamped()           # odom 到 base_footprint 的变换
            self._robot_position_xyz_init = np.zeros(3)         # 位置信息初始化
            self._robot_orientation_xyzw_init = np.zeros(4)     # 角度信息初始化
            self.__init_position_flag = False                   # 位置信息初始化标志位
            self._robot_odom_pub = self.create_publisher(Odometry,"robot/odom",10,callback_group=autoware_callback_group)
            self._robot_get_odom_sub = self.create_subscription(Odometry, '/odom', self._robot_get_odom_cb, 10 , callback_group=autoware_callback_group)
            self._robot_odom_pub_timer = self.create_timer(1.0/30,self._robot_odom_pub_timer_callback,callback_group=autoware_callback_group)
            self._robot_odom_tf2_timer = self.create_timer(1.0/50,self._robot_odom_tf2_timer_callback,callback_group=autoware_callback_group)
            self._robot_static_tf2_map_foot()
            
            # 单线激光雷达 robot_laser_link
            self._robot_laserscan = LaserScan()                 # lasersan数据
            self._robot_laser_tf2 = TransformStamped()          #   odom 到 base_footprint 的变换
            self._robot_get_laserscan_sub = self.create_subscription(LaserScan,"/scan", self._robot_get_lasersacan_cb, 10 , callback_group=autoware_callback_group)
            self._robot_laserscan_pub = self.create_publisher(LaserScan,'robot/scan',10,callback_group=autoware_callback_group)
            self._robot_laserscan_pub_timer = self.create_timer(1.0/15, self._robot_laserscan_pub_timer_callback,callback_group=autoware_callback_group)
            # self._robot_laser_tf2_timer = self.create_timer(1.0/50, self._robot_laser_tf2_timer_callback,callback_group=autoware_callback_group)
            self._robot_static_tf2_base_sllaser()
            
        #############
        #   car
        #############
        elif self.lgsvl_state == "car" :
            self._car_static_mo = StaticTransformBroadcaster(self)          # map 到 car_odom 静态连接
            self._car_static_bc = StaticTransformBroadcaster(self)         # car_base_footprint 到 car_camera 静态连接
            self._car_static_blf = StaticTransformBroadcaster(self)         # car_base_footprint 到 car_lidar_front 静态连接
            self._car_static_blr = StaticTransformBroadcaster(self)         # car_base_footprint 到 car_lidar_rear 静态连接
            self._car_static_bi = StaticTransformBroadcaster(self)          # car_base_footprint 到 car_imu 静态连接
            
            # 里程计 car_odom
            self._car_odom = Odometry()                         # odom数据
            self._car_odom_tf2 = TransformStamped()             # odom 到 base_footprint 的变换
            self._car_position_xyz_init = np.zeros(3)           # 位置信息初始化
            self._car_orientation_xyzw_init = np.zeros(4)       # 角度信息初始化
            self.__init_position_flag = False                   # 位置信息初始化标志位
            self._car_get_odom_sub = self.create_subscription(Odometry, '/lgsvl/gnss_odom', self._car_get_odom_cb, 10 , callback_group=autoware_callback_group)
            self._car_odom_pub = self.create_publisher(Odometry,"car/odom",10,callback_group=autoware_callback_group)
            self._car_odom_pub_timer = self.create_timer(1.0/30,self._car_odom_pub_timer_callback,callback_group=autoware_callback_group)
            self._car_odom_tf2_timer = self.create_timer(1.0/50,self._car_odom_tf2_timer_callback,callback_group=autoware_callback_group)
            self._car_static_tf2_map_foot()
            # 前雷达 car_lidar_front
            self._car_lidar_front = PointCloud2()                   # car_lidar_front
            self._car_lidar_front_tf2 = TransformStamped()          # car_lidar_front 到 base_footprint 的变换
            self._car_get_lidar_front_sub = self.create_subscription(PointCloud2,"/lidar_front/points_raw", self._car_get_lidar_front_cb, 10 , callback_group=autoware_callback_group)
            self._car_lidar_front_pub = self.create_publisher(PointCloud2,'car/lidar_front',10,callback_group=autoware_callback_group)
            self._car_lidar_front_pub_timer = self.create_timer(1.0/10, self._car_lidar_front_pub_timer_callback,callback_group=autoware_callback_group)
            self._car_static_tf2_lidar_front_foot()
            # 后雷达 car_lidar_rear
            self._car_lidar_rear = PointCloud2()                    # car_lidar_rear
            self._car_lidar_rear_tf2 = TransformStamped()           # odom 到 base_footprint 的变换
            self._car_get_lidar_rear_sub = self.create_subscription(PointCloud2,"/lidar_rear/points_raw", self._car_get_lidar_rear_cb, 10 , callback_group=autoware_callback_group)
            self._car_lidar_rear_pub = self.create_publisher(PointCloud2,'car/lidar_rear',10,callback_group=autoware_callback_group)
            self._car_lidar_rear_pub_timer = self.create_timer(1.0/10, self._car_lidar_rear_pub_timer_callback,callback_group=autoware_callback_group)
            self._car_static_tf2_lidar_rear_foot()
            # 惯导 car_imu
            self._car_imu = Imu()                    # car_imu
            self._car_imu_tf2 = TransformStamped()           # odom 到 base_footprint 的变换
            self._car_get_imu_sub = self.create_subscription(Imu,"/imu/imu_raw", self._car_get_imu_cb, 10 , callback_group=autoware_callback_group)
            self._car_imu_pub = self.create_publisher(Imu,'car/imu',10,callback_group=autoware_callback_group)
            self._car_imu_pub_timer = self.create_timer(1.0/50, self._car_imu_pub_timer_callback,callback_group=autoware_callback_group)
            self._static_tf_base_imu()
            # 相机 car_camera
            self._car_camera = CompressedImage()            
            self._car_imu_tf2 = TransformStamped()
            self._car_get_camera_sub = self.create_subscription(CompressedImage,"/image/compressed", self._car_get_camera_cb, 10 , callback_group=autoware_callback_group)
            self._car_camera_pub = self.create_publisher(CompressedImage,'car/camera/image/compressed', 10 , callback_group=autoware_callback_group)
            self._car_camera_pub_timer = self.create_timer(1.0/15, self._car_camera_pub_timer_callback,callback_group=autoware_callback_group)
            self._static_tf_base_camera()
        else :
            self.get_logger().error("Please set the autoware_mode param or the param is unuseful : %s " % self.lgsvl_state )
            return
            
        self.get_logger().info("\033[1;32m %s %s \033[0m" % ("Launch tf2 success ! Get lgsvl_state or autoware_mode param is :" , self.lgsvl_state ))
        
    '''
        autoware_robot
    '''
    def _robot_odom_init(self):
        self._robot_position_xyz_init[0] = self._robot_odom.pose.pose.position.x
        self._robot_position_xyz_init[1] = self._robot_odom.pose.pose.position.y
        self._robot_position_xyz_init[2] = self._robot_odom.pose.pose.position.z
        self._robot_orientation_xyzw_init[0] = self._robot_odom.pose.pose.orientation.x
        self._robot_orientation_xyzw_init[1] = self._robot_odom.pose.pose.orientation.y
        self._robot_orientation_xyzw_init[2] = self._robot_odom.pose.pose.orientation.z
        self._robot_orientation_xyzw_init[3] = self._robot_odom.pose.pose.orientation.w
        self.__init_position_flag = True
        self.get_logger().info("The location information has been initialized !")
    
    # robot 里程计
    def _robot_get_odom_cb(self,odom_msg) :
        self._robot_odom = odom_msg
        if self.__init_position_flag == False :
            self._robot_odom_init()
        self._robot_odom.header.frame_id = 'robot_odom'
        self._robot_odom.child_frame_id = 'robot_base_footprint'
        self._robot_odom.pose.pose.position.x = odom_msg.pose.pose.position.x - self._robot_position_xyz_init[0]
        self._robot_odom.pose.pose.position.y = odom_msg.pose.pose.position.y - self._robot_position_xyz_init[1]
        self._robot_odom.pose.pose.position.z = odom_msg.pose.pose.position.z - self._robot_position_xyz_init[2]
        # self._robot_odom.pose.pose.orientation.x = odom_msg.pose.pose.orientation.x - self._robot_orientation_xyzw_init[0]
        # self._robot_odom.pose.pose.orientation.y = odom_msg.pose.pose.orientation.y - self._robot_orientation_xyzw_init[1]
        # self._robot_odom.pose.pose.orientation.z = odom_msg.pose.pose.orientation.z - self._robot_orientation_xyzw_init[2]
        # self._robot_odom.pose.pose.orientation.w = odom_msg.pose.pose.orientation.w - self._robot_orientation_xyzw_init[3]
    def _robot_odom_pub_timer_callback(self) :
        self._robot_odom.header.stamp = self.get_clock().now().to_msg()
        self._robot_odom.header.frame_id = 'robot_odom'
        self._robot_odom.child_frame_id = 'robot_base_footprint'
        self._robot_odom_pub.publish(self._robot_odom)
    def _robot_odom_tf2_timer_callback(self):
        self._robot_odom_tf2.header.stamp = self.get_clock().now().to_msg()
        self._robot_odom_tf2.header.frame_id = 'robot_odom'
        self._robot_odom_tf2.child_frame_id = 'robot_base_footprint'
        self._robot_odom_tf2.transform.translation.x = self._robot_odom.pose.pose.position.x
        self._robot_odom_tf2.transform.translation.y = self._robot_odom.pose.pose.position.y
        self._robot_odom_tf2.transform.translation.z = self._robot_odom.pose.pose.position.z
        self._robot_odom_tf2.transform.rotation.x = self._robot_odom.pose.pose.orientation.x
        self._robot_odom_tf2.transform.rotation.y = self._robot_odom.pose.pose.orientation.y
        self._robot_odom_tf2.transform.rotation.z = self._robot_odom.pose.pose.orientation.z
        self._robot_odom_tf2.transform.rotation.w = self._robot_odom.pose.pose.orientation.w
        self._br.sendTransform(self._robot_odom_tf2)
    
    # robot 激光雷达
    def _robot_get_lasersacan_cb(self,laser_msg) :
        self._robot_laserscan = laser_msg
    def _robot_laserscan_pub_timer_callback(self):
        self._robot_laserscan.header.stamp = self.get_clock().now().to_msg()
        self._robot_laserscan.header.frame_id = "robot_laser_link"
        self._robot_laserscan_pub.publish(self._robot_laserscan)
    def _robot_laser_tf2_timer_callback(self):
        self._robot_laser_tf2.header.stamp = self.get_clock().now().to_msg()
        self._robot_laser_tf2.header.frame_id = 'robot_base_footprint'
        self._robot_laser_tf2.child_frame_id = 'robot_laser_link'
        self._robot_laser_tf2.transform.translation.x = 0.0865
        self._robot_laser_tf2.transform.translation.y = 0.0
        self._robot_laser_tf2.transform.translation.z = 0.145
        # self._robot_laser_tf2.transform.rotation.x = 0.0
        # self._robot_laser_tf2.transform.rotation.y = 0.0
        # self._robot_laser_tf2.transform.rotation.z = 0.0
        # self._robot_laser_tf2.transform.rotation.w = 0.0
        self._br.sendTransform(self._robot_laser_tf2)
        
    # 静态连接 里程计和地图 :
    def _robot_static_tf2_map_foot(self):
        _odom_static_tf2_msg = TransformStamped()
        _odom_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _odom_static_tf2_msg.header.frame_id = 'map'
        _odom_static_tf2_msg.child_frame_id = 'robot_odom'
        _odom_static_tf2_msg.transform.translation.x = 0.0
        _odom_static_tf2_msg.transform.translation.y = 0.0
        _odom_static_tf2_msg.transform.translation.z = 0.0
        self._robot_static_mo.sendTransform(_odom_static_tf2_msg)
        
    # 静态连接 单线激光雷达 :
    def _robot_static_tf2_base_sllaser(self):
        _laser_static_tf_msg31 = TransformStamped()
        _laser_static_tf_msg31.header.stamp = self.get_clock().now().to_msg()
        _laser_static_tf_msg31.header.frame_id = 'robot_base_footprint'
        _laser_static_tf_msg31.child_frame_id = 'robot_laser_link'
        _laser_static_tf_msg31.transform.translation.x = 0.0865
        _laser_static_tf_msg31.transform.translation.y = 0.0
        _laser_static_tf_msg31.transform.translation.z = 0.145
        # _laser_static_tf_msg31.transform.rotation.x = 0.0
        # _laser_static_tf_msg31.transform.rotation.y = 0.0
        # _laser_static_tf_msg31.transform.rotation.z = 1.0
        # _laser_static_tf_msg31.transform.rotation.w = 0.0
        self._robot_static_bs.sendTransform(_laser_static_tf_msg31)
        
    '''
        autoware_car
    '''
    def _car_odom_init(self):
        self._car_position_xyz_init[0] = self._car_odom.pose.pose.position.x
        self._car_position_xyz_init[1] = self._car_odom.pose.pose.position.y
        self._car_position_xyz_init[2] = self._car_odom.pose.pose.position.z
        self._car_orientation_xyzw_init[0] = self._car_odom.pose.pose.orientation.x
        self._car_orientation_xyzw_init[1] = self._car_odom.pose.pose.orientation.y
        self._car_orientation_xyzw_init[2] = self._car_odom.pose.pose.orientation.z
        self._car_orientation_xyzw_init[3] = self._car_odom.pose.pose.orientation.w
        self.__init_position_flag = True
        self.get_logger().info("The location information has been initialized !")
        
    # car 里程计
    def _car_get_odom_cb(self,odom_msg) :
        self._car_odom = odom_msg
        if self.__init_position_flag == False :
            self._car_odom_init()
        self._car_odom.header.frame_id = 'car_odom'
        self._car_odom.child_frame_id = 'car_base_footprint'
        self._car_odom.pose.pose.position.x = odom_msg.pose.pose.position.x - self._car_position_xyz_init[0]
        self._car_odom.pose.pose.position.y = odom_msg.pose.pose.position.y - self._car_position_xyz_init[1]
        self._car_odom.pose.pose.position.z = odom_msg.pose.pose.position.z - self._car_position_xyz_init[2]
        # self._car_odom.pose.pose.orientation.x = odom_msg.pose.pose.orientation.x - self._car_orientation_xyzw_init[0]
        # self._car_odom.pose.pose.orientation.y = odom_msg.pose.pose.orientation.y - self._car_orientation_xyzw_init[1]
        # self._car_odom.pose.pose.orientation.z = odom_msg.pose.pose.orientation.z - self._car_orientation_xyzw_init[2]
        # self._car_odom.pose.pose.orientation.w = odom_msg.pose.pose.orientation.w - self._car_orientation_xyzw_init[3]
    def _car_odom_pub_timer_callback(self) :
        self._car_odom.header.stamp = self.get_clock().now().to_msg()
        self._car_odom.header.frame_id = 'car_odom'
        self._car_odom.child_frame_id = 'car_base_footprint'
        self._car_odom_pub.publish(self._car_odom)
    def _car_odom_tf2_timer_callback(self):
        self._car_odom_tf2.header.stamp = self.get_clock().now().to_msg()
        self._car_odom_tf2.header.frame_id = 'car_odom'
        self._car_odom_tf2.child_frame_id = 'car_base_footprint'
        self._car_odom_tf2.transform.translation.x = self._car_odom.pose.pose.position.x
        self._car_odom_tf2.transform.translation.y = self._car_odom.pose.pose.position.y
        self._car_odom_tf2.transform.translation.z = self._car_odom.pose.pose.position.z
        self._car_odom_tf2.transform.rotation.x = self._car_odom.pose.pose.orientation.x
        self._car_odom_tf2.transform.rotation.y = self._car_odom.pose.pose.orientation.y
        self._car_odom_tf2.transform.rotation.z = self._car_odom.pose.pose.orientation.z
        self._car_odom_tf2.transform.rotation.w = self._car_odom.pose.pose.orientation.w
        self._br.sendTransform(self._car_odom_tf2)
    # 静态连接 里程计和地图 :
    def _car_static_tf2_map_foot(self):
        _odom_static_tf2_msg = TransformStamped()
        _odom_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _odom_static_tf2_msg.header.frame_id = 'map'
        _odom_static_tf2_msg.child_frame_id = 'car_odom'
        _odom_static_tf2_msg.transform.translation.x = 0.0
        _odom_static_tf2_msg.transform.translation.y = 0.0
        _odom_static_tf2_msg.transform.translation.z = 0.0
        self._car_static_mo.sendTransform(_odom_static_tf2_msg)
        
    # car 前激光雷达
    def _car_get_lidar_front_cb(self,laser_msg) :
        self._car_lidar_front = laser_msg
    def _car_lidar_front_pub_timer_callback(self):
        self._car_lidar_front.header.stamp = self.get_clock().now().to_msg()
        self._car_lidar_front.header.frame_id = "car_lidar_front_link"
        self._car_lidar_front_pub.publish(self._car_lidar_front)
    # 静态连接 lidar_front -> car_base_footprint :
    def _car_static_tf2_lidar_front_foot(self):
        _lidar_front_static_tf2_msg = TransformStamped()
        _lidar_front_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _lidar_front_static_tf2_msg.header.frame_id = 'car_base_footprint'
        _lidar_front_static_tf2_msg.child_frame_id = 'car_lidar_front_link'
        _lidar_front_static_tf2_msg.transform.translation.x = 0.5
        _lidar_front_static_tf2_msg.transform.translation.y = 0.0
        _lidar_front_static_tf2_msg.transform.translation.z = 2.0
        self._car_static_blf.sendTransform(_lidar_front_static_tf2_msg)
    
    # car 后激光雷达
    def _car_get_lidar_rear_cb(self,laser_msg) :
        self._car_lidar_rear = laser_msg
    def _car_lidar_rear_pub_timer_callback(self):
        self._car_lidar_rear.header.stamp = self.get_clock().now().to_msg()
        self._car_lidar_rear.header.frame_id = "car_lidar_rear_link"
        self._car_lidar_rear_pub.publish(self._car_lidar_rear)
    # 静态连接 lidar_rear -> car_base_footprint :
    def _car_static_tf2_lidar_rear_foot(self):
        _lidar_rear_static_tf2_msg = TransformStamped()
        _lidar_rear_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _lidar_rear_static_tf2_msg.header.frame_id = 'car_base_footprint'
        _lidar_rear_static_tf2_msg.child_frame_id = 'car_lidar_rear_link'
        _lidar_rear_static_tf2_msg.transform.translation.x = -0.5
        _lidar_rear_static_tf2_msg.transform.translation.y = 0.0
        _lidar_rear_static_tf2_msg.transform.translation.z = 2.0
        self._car_static_blr.sendTransform(_lidar_rear_static_tf2_msg)
        
    # imu 惯导 :
    def _car_get_imu_cb(self,imu_msg) :
        self._car_imu = imu_msg
    def _car_imu_pub_timer_callback(self):
        self._car_imu.header.stamp = self.get_clock().now().to_msg()
        self._car_imu.header.frame_id = "car_imu_link"
        self._car_imu_pub.publish(self._car_imu)
    def _static_tf_base_imu(self):
        _imu_static_tf2_msg = TransformStamped()
        _imu_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _imu_static_tf2_msg.header.frame_id = 'car_base_footprint'
        _imu_static_tf2_msg.child_frame_id = 'car_imu_link'
        _imu_static_tf2_msg.transform.translation.x = 0.0
        _imu_static_tf2_msg.transform.translation.y = 0.0
        _imu_static_tf2_msg.transform.translation.z = 0.0
        self._car_static_bi.sendTransform(_imu_static_tf2_msg)
        
    # camera 相机:
    def _car_get_camera_cb(self,camera_msg) :
        self._car_camera = camera_msg
    def _car_camera_pub_timer_callback(self):
        self._car_camera.header.stamp = self.get_clock().now().to_msg()
        self._car_camera.header.frame_id = "car_camera_link"
        self._car_camera_pub.publish(self._car_camera)
    def _static_tf_base_camera(self):
        _camera_static_tf2_msg = TransformStamped()
        _camera_static_tf2_msg.header.stamp = self.get_clock().now().to_msg()
        _camera_static_tf2_msg.header.frame_id = 'car_base_footprint'
        _camera_static_tf2_msg.child_frame_id = 'car_camera_link'
        _camera_static_tf2_msg.transform.translation.x = 1.0
        _camera_static_tf2_msg.transform.translation.y = 0.0
        _camera_static_tf2_msg.transform.translation.z = 0.5
        self._car_static_bc.sendTransform(_camera_static_tf2_msg)
    

def main():
    rclpy.init(args=None)
    _tf2 = TF2()
    rclpy.spin(_tf2)
    _tf2.destroy_node()
    rclpy.shutdown()

if __name__=="__main__":
    main()