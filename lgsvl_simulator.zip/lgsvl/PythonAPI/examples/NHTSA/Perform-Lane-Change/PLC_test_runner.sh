#!/bin/sh

set -eu

python3 PLC_B_15.py
python3 PLC_B_25.py
python3 PLC_B_35.py
python3 PLC_CP_15.py
python3 PLC_CP_25.py
python3 PLC_CP_35.py
python3 PLC_SN_15.py
python3 PLC_SN_25.py
python3 PLC_SN_35.py
python3 PLC_SP_15.py
python3 PLC_SP_25.py
python3 PLC_SP_35.py