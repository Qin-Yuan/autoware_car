#!/bin/sh

set -eu

python3 VF_S_25_Slow.py
python3 VF_S_45_Slow.py
python3 VF_S_65_Slow.py
# python3 VF_C_25_Slow.py
# python3 VF_C_45_Slow.py
# python3 VF_C_65_Slow.py
