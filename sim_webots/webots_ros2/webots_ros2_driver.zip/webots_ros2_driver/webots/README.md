# webots-libcontroller

This branch is a subset of the Webots repository, containing the controller library only.
It is primarily created to allow compilation of the [`webots_ros2`](https://github.com/cyberbotics/webots_ros2) interface without dependency on the complete Webots repository.